------ setup sql to test it out it works...
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    hash TEXT NOT NULL,
    cash NUMERIC NOT NULL DEFAULT 10000.00
);

CREATE UNIQUE INDEX idx_username ON users (username);

DROP TABLE IF EXISTS transactions;
CREATE TABLE transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    shares INTEGER NOT NULL,
    price NUMERIC NOT NULL,
    type TEXT NOT NULL,
    time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX idx_trans_user_id ON transactions (user_id);
CREATE INDEX idx_trans_symbol ON transactions (symbol);

DROP VIEW IF EXISTS history_view;
CREATE VIEW history_view AS
SELECT
    user_id,
    symbol,
    shares,
    price,
    type,
    time
FROM transactions;

SELECT 'Database setup complete!' AS status;
