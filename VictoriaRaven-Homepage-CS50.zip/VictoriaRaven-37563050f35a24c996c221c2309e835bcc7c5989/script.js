// Custom JavaScript for any additional interactivity
// For now, we're using Bootstrap's modals, but you can add more scripts here if needed.

// Q & A Game Logic
document.addEventListener("DOMContentLoaded", function () {
  // answers correct t and f wrong
  const answers = {
    q1b: true,
    q2c: true,
    q3b: true,
    q4c: true,
    q5b: true,
    q6a: true,
    q7b: true,
    q8a: true,
    q9b: true,
    q10a: true
  };

  document.querySelectorAll("button.btn-outline-secondary").forEach(button => {
    button.addEventListener("click", function () {
      const modalBody = button.closest(".modal-body");
      const closeButton = modalBody.querySelector(".close-btn");

      // Reset
      modalBody.querySelectorAll("button.btn-outline-secondary").forEach(b => {
        b.style.backgroundColor = "";
        b.style.color = "";
      });

      // Mark answer
      if (answers[button.id]) {
        button.style.backgroundColor = "green";
        button.style.color = "white";
      } else {
        button.style.backgroundColor = "red";
        button.style.color = "white";
      }

      // close button
      closeButton.style.display = "inline-block";
    });
  });
});

  // About Me toggle
function toggleAbout() {
  const moreText = document.getElementById('more-about');

  if (window.getComputedStyle(moreText).display === 'none') {
    moreText.style.display = 'block';
  } else {
    moreText.style.display = 'none';
  }
}


  // Interests dropdown
// Function to show detailed information about the user's selected interest
function showInterestDetails() {
  const value = document.getElementById('interest-dropdown').value;
  const output = document.getElementById('interest-output');

  const details = {
    software: `
      <h4>Software Engineering & Development</h4>
      <p>Software engineering is about planning, building, testing, and maintaining software that works well and solves real problems. It includes both front-end and back-end work:</p>
      <ul>
        <li><b>Front-end:</b> This is what users see and interact with on the screen. Right now, I’m working in front-end development and focusing on making websites accessible using ADA (Americans with Disabilities Act) and WCAG (Web Content Accessibility Guidelines). I make sure pages are easy to use for everyone, including people with disabilities.</li>
        <li><b>Back-end:</b> This is everything that happens behind the scenes, like databases, servers, and APIs. I’m learning and working toward gaining more back-end experience so I can build full-stack applications from start to finish.</li>
      </ul>
      <p>Full-stack development means handling both front-end and back-end parts of a project. That’s my goal as I keep learning and building my skills.</p>
      <p>The Software Development Life Cycle (SDLC) is a roadmap that guides projects through planning, designing, building, testing, and maintenance. Version control tools like Git help teams track changes and work together smoothly.</p>
    `,

    cybersecurity: `
      <h4>Cybersecurity & Cryptography</h4>
      <p>Cybersecurity is all about keeping data, networks, and systems safe from hackers and other online threats. It connects closely with the work I do in front-end development, especially around making websites secure and accessible at the same time.</p>

      <h5>Accessibility and Security</h5>
      <p>When building websites that follow ADA and WCAG guidelines, I also think about security. Accessibility and security go hand in hand as it focuses on creating safe web browsing for all users. For example:</p>
      <ul>
        <li>- Secure front-end design</li>
        <li>- Compliance and privacy</li>
        <li>- Safe login and data forms</li>
      </ul>

      <h5>How CompTIA Network+ Fits Into This?</h5>
      <p>CompTIA Network+ builds a strong base for understanding how computers and systems connect and share data safely covering:</p>
      <ul>
        <li>1) Network basics</li>
        <li>2) Encryption and protocols</li>
        <li>3) Network security</li>
      </ul>

      <h5>And how does other CompTIA Security+ and other certificates related?</h5>
      <p>After Network+, the next step is CompTIA Security+, which digs deeper into topics like encryption, risk management, and identity protection.</p>
      <p>For me, cybersecurity and IT connects everything I do with Frontend (Web Developing) as it is realted to accessibility, secure coding, and understanding how networks protect user data. I learned that it’s about building safe and trustworthy software for others to use and send/retrive data to each other...</p>
    `,

    ai: `
      <h4>AI & Machine Learning</h4>
      <p>AI and machine learning are changing how humans work and learn/make decisions by letting computers analyze data and find patterns to make a conclusions like:</p>
      <ul>
        <li><b>Law and research:</b> AI tools can read and summarize huge sets of documents, be a database for law like Westlaw or Nexis Uni by helping lawyers find key information faster.</li>
        <li><b>National security:</b> Agencies like the FBI and CIA use AI to sort through data, find threats, and speed up investigations.</li>
      </ul>
    `,

    data: `
      <h4>Data Science & Law Integration</h4>
      <p>I did some research on the web and found that Data science is about finding solutions with large sets of information gathered like in law, the large data of legal definitons helps people make lawyers make faster and accurate decisions. In my legal studies class at UMGC some exmaples can include:</p>
      <ul>
        <li><b>Case law analysis:</b> AI tools can search through thousands of cases to find similar ones or key rulings.</li>
        <li><b>Contract/Analysis/Memorandum reviews:</b> Machine learning can help lawyers spot risks or errors in contracts/memorandums quickly.</li>
      </ul>
    `,

    math: `
      <h4>Mathematics & Physics</h4>
      <p>Mathematics and physics are the foundation for computer science, computer engineering, robotics, and AI. This is bewucase these subjects explain how systems move, react, and process information. For instance:</p>
      <ul>
        <li><b>Calculus:</b> Helps model and predict changes in systems like motion, energy, or growth in computer science.</li>
        <li><b>Linear algebra:</b> Used in robotics and AI for handling images, shapes, and data in many dimensions realted to computer science.</li>
        <li><b>Physics:</b> Even though this is not the main curriculum of CS, it explains how things move and interact; important for circuits, robotics, and sensors.</li>
      </ul>
    `
  };

  output.innerHTML = details[value] || "<p>Select my main focuses to see more details.</p>";
}


  // Fun facts dropdown
  function showFunDetails() {
    const value = document.getElementById('fun-dropdown').value;
    const output = document.getElementById('fun-output');
    const details = {
      languages: "I know French and Russian. I plan on learning Italian/Spanish depending on which is better and popular after the previous two languages that I enjoy.",
      music: "I have three instruments at home, including a virutal DJ set up and music production apps with Focusrite. Unfortunaltely, I do not have the best voice, so I cannot sing, but I can try to if allowed to use AI/autotune.",
      style: "I am most confident in formal/timeless clothing and experimenting with styles, even if I sometimes stand out in a crowd.",
      travel: "So far, I found it amazing this year that I was able to visit District of Columbia and enjoy discovering new cultures, food, and places.",
      wishes: "I dream of owning a Nissan GT-R (model type depends on that year I want to purchase it) and upgrading it fully, from underglow lights to top-tier speakers, paint, decals, spoliers, tires, and NOS.",
      entertainment: "Intrigingly, I watch more YouTube videos than any other streaming service combined!"
    };
    output.textContent = details[value] || "";
  }

  // Hobbies dropdown
  function showHobbyDetails() {
    const value = document.getElementById('hobby-dropdown').value;
    const output = document.getElementById('hobby-output');
    const details = {
      fitness: "1). I am continuing boxing, running, HIIT, martial arts, and defense training to stay fit and disciplined.",
      tech: "2). I am working on CompTIA certificates, other professional certificates, tinkering with circuits and cybersecurity/IT, and develop coding projects.",
      music: "3). Other times, I produce music with Focusrite/DJ, and have a YouTube channel for my creative works and potential monetization.",
      social: "4). I am balancing social outings with personal alone time to stay connected but not isolated.",
      creative: "5). Other times, I enjoy dancing, experimenting with cooking/eating out, and exploring creative projects in coding/tech/automechanic."
    };
    output.textContent = details[value] || "";
  }
