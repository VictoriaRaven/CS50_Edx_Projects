-- Keep a log of any SQL queries you execute as you solve the mystery.

-- crime scene reports table: theft on July 28, 2021, Humphrey Street at 10:15 am with witness
SELECT id, description
FROM crime_scene_reports
WHERE year = 2021
  AND month = 7
  AND day = 28
  AND street LIKE '%Humphrey%';

-- interview witnessess(anyone who mentioned the bakery) for clues:
-- 1 was theft 1 was another issue event; prioitze theft as it's more imporant
--generic:
SELECT name, transcript
  FROM interviews
 WHERE year = 2021
   AND month = 7
   AND day = 28;
---specific:
-- from three witnesses that had interview on July 28, 2021
SELECT name, transcript
FROM interviews
WHERE year = 2021
  AND month = 7
  AND day = 28
  AND transcript LIKE '%bakery%';
---Eugene;Raymond;Ruth.

-- Find who withdrew money from the ATM on Leggett Street that morning.
-- Then I must find account number and person of the transaction: clues form Eugene
FROM atm_transactions
WHERE year = 2021
  AND month = 7
  AND day = 28
  AND atm_location LIKE '%Leggett Street%'
  AND transaction_type = 'withdraw';

-- double checking through the name and atm_tranactions.amount
SELECT name, atm_transactions.amount
FROM people
JOIN bank_accounts ON people.id = bank_accounts.person_id
JOIN atm_transactions ON bank_accounts.account_number = atm_transactions.account_number
WHERE atm_transactions.year = 2021
  AND atm_transactions.month = 7
  AND atm_transactions.day = 28
  AND atm_transactions.atm_location = 'Leggett Street'
  AND atm_transactions.transaction_type = 'withdraw';

-- After it is found of withdrawl, match those ATM account numbers to the person's account number
-- these would be the suspects since the witness are eliminated...
SELECT people.name, people.id, people.phone_number, people.license_plate
FROM people
JOIN bank_accounts ON people.id = bank_accounts.person_id
WHERE bank_accounts.account_number IN (
  SELECT account_number
  FROM atm_transactions
  WHERE year = 2021
    AND month = 7
    AND day = 28
    AND atm_location LIKE '%Leggett Street%'
    AND transaction_type = 'withdraw'
);

-- Check which cars left the bakery parking lot at those times
SELECT license_plate
FROM bakery_security_logs
WHERE year = 2021
  AND month = 7
  AND day = 28
  AND activity = 'exit'
  AND minute > 15
  AND minute <= 25;

-- Match those license plates to people.
SELECT name
FROM people
WHERE license_plate IN (
  SELECT license_plate
  FROM bakery_security_logs
  WHERE year = 2021
    AND month = 7
    AND day = 28
    AND activity = 'exit'
    AND minute > 15
    AND minute <= 25
);

--Find short phone calls made that day
SELECT caller, receiver, duration
FROM phone_calls
WHERE year = 2021
  AND month = 7
  AND day = 28
  AND duration < 60;

--which of the suspects ATM/bakery people made these calls
SELECT DISTINCT name
FROM people
WHERE phone_number IN (
  SELECT caller
  FROM phone_calls
  WHERE year = 2021
    AND month = 7
    AND day = 28
    AND duration < 60
);

--Find Fiftyville’s airport (the thief’s departure point).
SELECT id, abbreviation, full_name, city
FROM airports
WHERE city = 'Fiftyville';

--List all flights leaving Fiftyville on July 29, 2021, sorted by time.
SELECT flights.id, airports.full_name, airports.city, flights.hour, flights.minute
FROM flights
JOIN airports ON flights.destination_airport_id = airports.id
WHERE flights.origin_airport_id = (SELECT id FROM airports WHERE city = 'Fiftyville')
  AND flights.year = 2021
  AND flights.month = 7
  AND flights.day = 29
ORDER BY flights.hour, flights.minute;

--Find the earliest flight leaving Fiftyville on July 29, 2021 (8:20)
SELECT id, origin_airport_id, destination_airport_id, hour, minute
FROM flights
WHERE year = 2021
  AND month = 7
  AND day = 29
ORDER BY hour, minute
LIMIT 1;

-- find where that flight went 8:20.
SELECT city
FROM airports
WHERE id = (
  SELECT destination_airport_id
  FROM flights
  WHERE year = 2021
    AND month = 7
    AND day = 29
  ORDER BY hour, minute
  LIMIT 1
);

--List all passengers on that 8:20 flight.
SELECT people.name, passengers.passport_number, passengers.seat
FROM people
JOIN passengers ON people.passport_number = passengers.passport_number
JOIN flights ON passengers.flight_id = flights.id
WHERE flights.id = 36
ORDER BY passengers.passport_number;

-- Narrow the search with more specfic details: List passengers on that earliest flight 8:20 by checking it each person, id, city, and destination
SELECT people.name, flights.id AS flight_id, airports.city AS destination_city
FROM people
JOIN passengers ON people.passport_number = passengers.passport_number
JOIN flights ON passengers.flight_id = flights.id
JOIN airports ON flights.destination_airport_id = airports.id
WHERE flights.year = 2021
  AND flights.month = 7
  AND flights.day = 29
  AND flights.id = (
    SELECT id
    FROM flights
    WHERE year = 2021
      AND month = 7
      AND day = 29
    ORDER BY hour, minute
    LIMIT 1
  );

--all the cluses matches with Bruce and now check him
--Find who is Bruce's accomplice
SELECT receiver
FROM phone_calls
WHERE year = 2021
  AND month = 7
  AND day = 28
  AND duration < 60
  AND caller = (
    SELECT phone_number
    FROM people
    WHERE name = 'Bruce'
  );

  --  now use the number to find the name
SELECT name
FROM people
WHERE phone_number IN (
  SELECT receiver
  FROM phone_calls
  WHERE year = 2021
    AND month = 7
    AND day = 28
    AND duration < 60
    AND caller = (
      SELECT phone_number
      FROM people
      WHERE name = 'Bruce'
    )
);

-- Result from all clues: Bruce called Robin.
-- The THIEF is: Bruce
-- The city the thief ESCAPED TO: New York City
-- The ACCOMPLICE is: Robin
/*
fiftyville/ $ check50 cs50/problems/2025/x/fiftyville
Connecting......
Authenticating....
Verifying......
Preparing.....
Uploading......
Waiting for results..................
Results for cs50/problems/2025/x/fiftyville generated by check50 v4.0.0.dev0
:) log.sql and answers.txt exist
:) log file contains SELECT queries
:) mystery solved
To see more detailed results go to https://submit.cs50.io/check50/1cfeab830ec1631121d832597fc189cd203ed7fd
fiftyville/ $
*/
